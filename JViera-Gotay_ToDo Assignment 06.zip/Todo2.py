#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  Sept 16, 2017
# ChangeLog: (Who, When, What)
#   RRoot, 09/16/2017, Created Script
#   JViera-Gotay, 2/17/2019, Add/declare Class and Functions

#-------------------------------------------------#
#Pseudocode

# Place code into Functions
# Group Functions in a Class

# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo2.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo2.txt file

# Step 7
# Exit program
#-------------------------------1
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo2.txt into a python Dictionary.

class MyToDoList():
    '''This class contains functions methods for maintaining
    inventory tasks and prorities'''

    @staticmethod # decorator flag/define method
    def LoadData(Todo2):
        '''Function loads and reads Todo2 data'''

        objFile = open(Todo2, "r")
        for line in objFile:
            lstData = line.split(",") # readline() reads a line of the data into 2 elements
            dicRow = {"Task":lstData[0].strip(), "Priority":lstData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()
        return lstTable #return statment expression exits the function

    @staticmethod  # decorator flag/define method
    def DisplayData(myTasks):
        '''Function displays myTasks data '''

        print("******* The current items ToDo are: *******")
        for row in myTasks:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")

    @staticmethod # decorator flag/define method
    def AddTask():
        '''Function to add tasks to ToDo2 file'''

        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        dicRow = {"Task": strTask, "Priority": strPriority}
        lstTable.append(dicRow)
        print("Current Data in table:")
        for dicRow in lstTable:
            print(dicRow)
            # 4a Show the current items in the table
            print("******* The current items ToDo are: *******")
            for row in lstTable:
                print(row["Task"] + "(" + row["Priority"] + ")")
            print("*******************************************")
            continue  # to show the menu

    @staticmethod # decorator flag/define method
    def RemoveTask():
        '''Functon to remove tasks'''

        # 5a-Allow user to indicate which row to delete
        strKeyToRemove = input("Which TASK would you like removed? - ")
        blnItemRemoved = False  # Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove == str(list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
                del lstTable[intRowNumber]
                blnItemRemoved = True
            # end if
            intRowNumber += 1
            # end for loop
            # 5b-Update user on the status
        if (blnItemRemoved == True):
                print("The task was removed.")
        else:
                print("I'm sorry, but I could not find that task.")

    @staticmethod # decorator flag/define method
    def SaveTasks():
        '''Function to save tasks'''

        # 5a Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        # 5b Ask if they want save that data
        if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")


objFileName = "C:\_PythonClass\\Assignment06\\Todo2.txt"
strData = ""
dicRow = {}
lstTable = []

# global MyToDoList variable abstracted from being inside
# my def LoadData function
lstTable = MyToDoList.LoadData(objFileName)

# Step 2
# Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line

    # Step 3
    # Show the current items in the table
    if (strChoice.strip() == '1'):
        # tells Python that the block of code in DisplayData is to be used together
        #when it's pass in the myToDoList class
        MyToDoList.DisplayData(myTasks=lstTable)

    # Step 4
    # Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        # tells Python that the block of code AddTask is to be used together
        # when it's pass in the myToDoList class
        MyToDoList.AddTask()

    # Step 5
    # Remove a new item to the list/Table
    elif(strChoice == '3'):
        # tells Python that the block of code in RemoveTask is to be used together
        # when it's pass in the myToDoList class
        MyToDoList.RemoveTask()

    # Step 6
    # Save tasks to the ToDo2.txt file
    elif(strChoice == '4'):
        # tells Python that the block of code in SaveTasks is to be used together
        # when it's pass in the myToDoList class
        MyToDoList.SaveTasks()
        continue # show the menu

    elif (strChoice == '5'):
        break #and Exit the program

