#--------------------------------------#
# Title: Pickling #
# Dev: JVG #
# Date: Feb 25,2019 #
# ChangeLog:none yet #
#---------------------------------------#
# Pseudocode
# Demonstrate Pickling and Shelving data (extra0
# Create three pickling lists and write to dat file
# open the file to store the data
# use dump function to write pickled lists to file
# Unpickle the three lists
# print unpickled lists to double-check process works
# Shelve the list together in a singe file
# invoke sync to make sure data is written
# Display lists



# pickle module allows to store complex data in a file
# Shelve allows to store and access pickled objects
import pickle, shelve

print("Pickling lists.")
# movie pickle lists
rating = ["PG-13", "R", "G"]
title = ["Prometheus", "You've Got Mail", "Miss Congeniality"]
genre = ["Sci-fi", "Romance", "Comedy"]
# open a file to store the data
f = open("movies.dat", "wb")
# dump function writes pickled lists to file
pickle.dump(rating, f)
pickle.dump(title, f)
pickle.dump(genre, f)
f.close()

print("\nUnpickling lists.")
# pickle.load function, retrieves and unpickle the three lists
f = open("movies.dat", "rb")
rating = pickle.load(f)
title = pickle.load(f)
genre = pickle.load(f)
# print unpickled lists to to demonstrate process works
print(rating)
print(title)
print(genre)
f.close()

print("\nShelving lists.")

# Call open shelve module
s = shelve.open("movies2.dat")
s["rating"] = ["PG-13", "R", "G"]
s["title"] = ["Prometheus", "You've Got Mail", "Miss Congeniality"]
s["genre"] = ["Sci-fi", "Romance", "Comedy"]
# invoke sync to make sure data is written
s.sync()

print("\nRetrieving lists from a shelved file:")
print("genre -", s["genre"])
print("title -", s["title"])
print("rating -", s["rating"])
s.close()

input("\n\nPress the enter key to exit.")

