# Title: Exception Handling #
# Dev: JVG #
# Date: Feb 25,2019 ##--------------------------------------#
# ChangeLog:none yet #
#---------------------------------------#
# Pseudocode
# Demonstrate Exception Handling
# Get user numerical input data
# If user enters a text string, Python throws a "ValueError"
# Create a "try-except" block to handle the exception
# Upon block execution, display to the user exiting program message and close
# If user enters integers/numerical values continue in a While Loop
# Display sum
# Ask user whether to continue or exit

print("\nGive me two numbers for me to calculate the sum.")

# response stores the value the user enters
response = ""

# a while loop condition that runs as long as the value of response != "no"
while response != "n":
    # try-except block statement
    try:
        # converts the input string value and returns an integer
        first_number = int(input("\nEnter the first number:\n "))
    # exception handling for "Value Error"
    except ValueError:
        print("User Error...Please enter a numerical value!")
        print("\nExiting Program!")
        break

    # converts the input string value and returns an integer
    second_number = int(input("Enter the second number:\n "))

    # variable statement returns the sum of first number + second number
    suma = first_number + second_number

    print("The sum =", suma)

    # Waits for the user to either continue or exit
    response = (input("\nAre there any other numbers would you like me add? (y/n):\n "))
    # if users enters "no", program closes
    if response == "n":
        break
    # if user enters "y" the program continues
    else:
        continue


