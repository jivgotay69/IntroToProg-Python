#-------------------------------------------------#
# Title: To Do
# Dev:   JViera-Gotay
# Date:  Feb 11, 2019
# ChangeLog: (Who, When, What)
#JViera-Gotay, 02/10/2019
#-------------------------------------------------#
#Pseudocode

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)
#-------------------------------


# Step 1 - Load data from a file

print("\nFollowing are your current Tasks and Priorities!\n")

# dictionaries contain different columns of data (Task, Priority)
# which are stored in a Python Dictionary.

dicRow = {"Task": "Clean House", "Priority": "Low"}
dicRow1 = {"Task": "Pay Bills", "Priority": "High"}

# Add the each dictionary "row" to a python list "table"
strTable = [dicRow, dicRow1]

# obFileTodo loads each "row" of data
# in "ToDo.txt" into a python Dictionary.

objFileTodo = open("C:\_PythonClass\\Assignment05\\Todo.txt", "w")
objFileTodo.write(str(strTable))

# closes the text file
objFileTodo.close()

# print Tasks Keys and Priority Values from strTable
for dicRow in strTable:
    print("{}({})".format(dicRow["Task"], dicRow["Priority"]))


print("\nPlease choose from the main menu options below")

# Step 2 - Display a menu of choices to the user
while(True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)

    # Display menu options to the user
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()

    # Display most current Tasks and Priority level
    if (strChoice.strip() == '1'):
        for dicRow in strTable:
            print(strTable)

    # Prompt the user to add new Tasks
    elif(strChoice.strip() == '2'):
        strTask = input("Enter a new task: " + "\n")
        strPriority = input("Enter a priority: " + "\n")
        dicNewRow = {"Task": strTask, "Priority": strPriority.replace('\n',"")}
        strTable.append(dicNewRow)
        print("\n", strTask, strPriority, "Task has been added.\n")

        for dicRow in strTable:
            print(strTable)

    # Prompt the user to remove Tasks
    elif(strChoice == '3'):
        task = input("\nWhich task would you like to remove?: " + "\n")
        if "Task" in dicRow1:
            del dicRow1["Task"]
            print("\nOk," "Task" "deleted")
        else:
           print("Task", "isn't in the Task List!")

    # Save tasks to the ToDo.txt file
    elif(strChoice == '4'):

        objFileTodo = open("C:\_PythonClass\\Assignment05\\Todo.txt", "a")
        objFileTodo.write(str(strTable))

        print("Task saved!")

        objFileTodo.close()

    # and Exit the program
    elif (strChoice == '5'):
        print("Good Bye!")
        break

